#include "stdafx.h"
#include "resource.h" 
#include "FileOperation.h"
#include "afxdialogex.h"
#include <string>
#include <cctype>


CFExeption::CFExeption(DWORD dwErrCode)
{
	LPVOID lpMsgBuf;
	FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL, dwErrCode, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), (LPTSTR)&lpMsgBuf, 0, NULL);
	m_sError = (LPTSTR)lpMsgBuf;
	LocalFree(lpMsgBuf);
	m_dwError = dwErrCode;
}

CFExeption::CFExeption(CString sErrText)
{
	m_sError = sErrText;
	m_dwError = 0;
}

//************************************************************************************************************//

CFileOperation::CFileOperation()
{
	Initialize();
}


void CFileOperation::Initialize()
{
	m_sError = _T("No error");
	m_dwError = 0;
	m_bAskIfReadOnly = true;
	m_bOverwriteMode = true;
	m_bAborted = false;
	m_iRecursionLimit = -1;
	png = false, jpg = false, txt = false;
}

void CFileOperation::DoFolderCopy(CString sSourceFolder, CString sDestFolder)
{
		CFileFind ff;
		if (!CreateDirectory(sDestFolder, NULL))
		{
			DWORD dwErr = GetLastError();
			if (dwErr != 183)
			{
				ff.Close();
				throw new CFExeption(dwErr);
			}
		}
		//CFileFind ff;
		CString sPathSource = sSourceFolder;
		BOOL bRes = ff.FindFile(sPathSource);
		while (bRes)
		{
			bRes = ff.FindNextFile();
			if (ff.IsDots()) continue;
			if (ff.IsDirectory()) // source is a folder
			{
				if (m_iRecursionLimit == 0) continue;
				sPathSource = ff.GetFilePath() + CString("\\") + CString("*.*");
				CString sPathDest = sDestFolder + ff.GetFileName() + CString("\\");
				if (CheckPath(sPathDest) == PATH_NOT_FOUND)
				{
					if (!CreateDirectory(sPathDest, NULL))
					{
						ff.Close();
						throw new CFExeption(GetLastError());
					}
				}
				if (m_iRecursionLimit > 0) m_iRecursionLimit--;
				DoFolderCopy(sPathSource, sPathDest);
			}
			else // source is a file
			{
				CString sNewFileName = sDestFolder + ff.GetFileName();
				DoFileCopy(ff.GetFilePath(), sNewFileName);
			}
		}
		ff.Close();
		AfxMessageBox(_T("COPIED SUCCESSFULLY"));
}

bool CFileOperation::FolderExists(CString strFolderName)
{
	return GetFileAttributes(strFolderName) != INVALID_FILE_ATTRIBUTES;
}

void CFileOperation::CheckAndCopy(CString sSourceFolder, CString sDestFolder)
{
	if (FolderExists(sDestFolder) == true)
	{
		const int result = MessageBox(NULL, L"Folder already exist. Do you still want to copy with same name?", L"WARNING !!", MB_YESNOCANCEL);

		switch (result)
		{
		case IDYES:
		{
			m_bOverwriteMode = true; // COPY FILES with as it is, if false: copy of ... 
			DoFolderCopy(sSourceFolder, sDestFolder);
		}
			break;
		case IDNO:
		{
			sDestFolder.Delete(sDestFolder.GetLength() - 1);
			BOOL bOvrwriteFails = FALSE;
			if (!m_bOverwriteMode)
			{
				while (FolderExists(sDestFolder)) // Every time Dest folder name changes as copy, copy (1) ... and if it doesn't exist in directory it will create one.
				{
					sDestFolder = ChangeFileName(sDestFolder);
				}
				bOvrwriteFails = TRUE;
			}
			PreparePath(sDestFolder);
			DoFolderCopy(sSourceFolder, sDestFolder);
		}
			break;
		case IDCANCEL:
			// Do nothing
			break;
		}
		//AfxMessageBox(_T("Folder Already Exist"));

	}
	else
		DoFolderCopy(sSourceFolder, sDestFolder);
}

void CFileOperation::DoCopy(CString sSource, CString sDest)
{
	CheckSelfRecursion(sSource, sDest);
	// source & Dest not found
	if (CheckPath(sSource) == PATH_NOT_FOUND && CheckPath(sDest) == PATH_NOT_FOUND)
	{
		CString sError = sSource + CString(" path not found");
		throw new CFExeption(sError);
	}
	// source not found
	if (CheckPath(sSource) == PATH_NOT_FOUND)
	{
		CString sError = sSource + CString(" Source path not found");
		throw new CFExeption(sError);
	}
	// dest not found
	if (CheckPath(sDest) == PATH_NOT_FOUND)
	{
		CString sError = sDest + CString(" Destination path not found");
		throw new CFExeption(sError);
	}
	if (png == false && jpg == false && txt == false && ctm == false && mrm == false)
		MessageBox(NULL, L"Please select the type of file you wanted to copy", _T("Error"), MB_OK | MB_ICONERROR);
	else
	{
		// folder to file
		if (CheckPath(sSource) == PATH_IS_FOLDER && CheckPath(sDest) == PATH_IS_FILE)
		{
			throw new CFExeption(_T("Wrong operation"));
		}
		// folder to folder
		if (CheckPath(sSource) == PATH_IS_FOLDER && CheckPath(sDest) == PATH_IS_FOLDER)
		{
			CFileFind ff;
			CString sError = sSource + CString(" not found");
			PreparePath(sSource);
			PreparePath(sDest);
			sSource += "*.*";
			if (!ff.FindFile(sSource))
			{
				ff.Close();
				throw new CFExeption(sError);
			}
			if (!ff.FindNextFile())
			{
				ff.Close();
				throw new CFExeption(sError);
			}
			CString sFolderName = ParseFolderName(sSource);
			if (!sFolderName.IsEmpty()) // the source is not drive
			{
				sDest += sFolderName;
				PreparePath(sDest);
			}
			ff.Close();
			CheckAndCopy(sSource, sDest);
		}
		// file to file
		if (CheckPath(sSource) == PATH_IS_FILE && CheckPath(sDest) == PATH_IS_FILE)
		{
			DoFileCopy(sSource, sDest);
		}
		// file to folder
		if (CheckPath(sSource) == PATH_IS_FILE && CheckPath(sDest) == PATH_IS_FOLDER)
		{
			PreparePath(sDest);
			wchar_t drive[MAX_PATH], dir[MAX_PATH], name[MAX_PATH], ext[MAX_PATH];
			_wsplitpath_s(sSource, drive, dir, name, ext);
			sDest = sDest + CString(name) + CString(ext);
			DoFileCopy(sSource, sDest);
		}
	}
}


void CFileOperation::DoFileCopy(CString sSourceFile, CString sDestFile)
{
	BOOL bOvrwriteFails = FALSE;
	if (!m_bOverwriteMode)
	{
		while (IsFileExist(sDestFile))
		{
			sDestFile = ChangeFileName(sDestFile);
		}
		bOvrwriteFails = TRUE;
	}
	CString sExt;
	wchar_t drive[MAX_PATH];
	wchar_t dir[MAX_PATH];
	wchar_t name[MAX_PATH];
	wchar_t ext[MAX_PATH];
	_wsplitpath_s((LPCTSTR)sDestFile, drive, dir, name, ext);
	sExt = ext;
	int length = sExt.GetLength();

	for (int i = 0; i < length; i++) {
		sExt.SetAt(i, std::tolower(sExt[i]));
	}
		if (sExt == L".png" && png == true)
			if (!CopyFile(sSourceFile, sDestFile, bOvrwriteFails)) throw new CFExeption(GetLastError());
		if (sExt == L".jpg" && jpg == true)
			if (!CopyFile(sSourceFile, sDestFile, bOvrwriteFails)) throw new CFExeption(GetLastError());
		if (sExt == L".dcm" && txt == true)
			if (!CopyFile(sSourceFile, sDestFile, bOvrwriteFails)) throw new CFExeption(GetLastError());
		if (sExt == L".dCM" && mrm == true)
				if (!CopyFile(sSourceFile, sDestFile, bOvrwriteFails)) throw new CFExeption(GetLastError());
}


bool CFileOperation::Copy(CString sSource, CString sDest, bool m_png, bool m_jpg, bool m_txt, bool m_ctm, bool m_mrm)
{
	png = m_png, jpg = m_jpg, txt = m_txt, ctm = m_ctm, mrm = m_mrm;
	if (CheckSelfCopy(sSource, sDest)) return true;
	bool bRes;
	try
	{
		DoCopy(sSource, sDest);
		bRes = true;
	}
	catch (CFExeption* e)
	{
		m_sError = e->GetErrorText();
		m_dwError = e->GetErrorCode();
		delete e;
		if (m_dwError == 0) bRes = true;
		bRes = false;
	}
	m_iRecursionLimit = -1;
	return bRes;
}

CString CFileOperation::ChangeFileName(CString sFileName)
{
	CString sName, sNewName, sResult;
	wchar_t drive[MAX_PATH];
	wchar_t dir[MAX_PATH];
	wchar_t name[MAX_PATH];
	wchar_t ext[MAX_PATH];
	_wsplitpath_s((LPCTSTR)sFileName, drive, dir, name, ext);
	sName = name;

	int pos = sName.Find(_T("Copy "));
	if (pos == -1)
	{
		sNewName = CString("Copy of ") + sName + CString(ext);
	}
	else
	{
		int pos1 = sName.Find('(');
		if (pos1 == -1)
		{
			sNewName = sName;
			sNewName.Delete(0, 8);
			sNewName = CString("Copy (1) of ") + sNewName + CString(ext);
		}
		else
		{
			CString sCount;
			int pos2 = sName.Find(')');
			if (pos2 == -1)
			{
				sNewName = CString("Copy of ") + sNewName + CString(ext);
			}
			else
			{
				sCount = sName.Mid(pos1 + 1, pos2 - pos1 - 1);
				sName.Delete(0, pos2 + 5);
				CT2A ascii(sCount);
				int iCount = atoi(ascii.m_psz);
				iCount++;
				sNewName = CString("Copy (") + (CString)(std::to_wstring(iCount).c_str()) + CString(") of ") + (LPCTSTR)sName + CString(ext);
			}
		}
	}

	sResult = CString(drive) + CString(dir) + sNewName;
	return sResult;
}


bool CFileOperation::IsFileExist(CString sPathName)
{
	HANDLE hFile;
	hFile = CreateFile(sPathName, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, NULL, NULL);
	if (hFile == INVALID_HANDLE_VALUE) return false;
	CloseHandle(hFile);
	return true;
}


int CFileOperation::CheckPath(CString sPath)
{
	DWORD dwAttr = GetFileAttributes(sPath);
	if (dwAttr == 0xffffffff)
	{
		if (GetLastError() == ERROR_FILE_NOT_FOUND || GetLastError() == ERROR_PATH_NOT_FOUND)
			return PATH_NOT_FOUND;
		return PATH_ERROR;
	}
	if (dwAttr & FILE_ATTRIBUTE_DIRECTORY) return PATH_IS_FOLDER;
	return PATH_IS_FILE;
}


void CFileOperation::PreparePath(CString &sPath)
{
	if (sPath.Right(1) != "\\") sPath += "\\";
}

CString CFileOperation::ParseFolderName(CString sPathName)
{
	CString sFolderName = sPathName;
	int pos = sFolderName.ReverseFind('\\');
	if (pos != -1) sFolderName.Delete(pos, sFolderName.GetLength() - pos);
	pos = sFolderName.ReverseFind('\\');
	if (pos != -1) sFolderName = sFolderName.Right(sFolderName.GetLength() - pos - 1);
	else sFolderName.Empty();
	return sFolderName;
}


void CFileOperation::CheckSelfRecursion(CString sSource, CString sDest)
{
	if (sDest.Find(sSource) != -1)
	{
		int i = 0, count1 = 0, count2 = 0;
		for (i = 0; i < sSource.GetLength(); i++)	if (sSource[i] == '\\') count1++;
		for (i = 0; i < sDest.GetLength(); i++)	if (sDest[i] == '\\') count2++;
		if (count2 >= count1) m_iRecursionLimit = count2 - count1;
	}
}


bool CFileOperation::CheckSelfCopy(CString sSource, CString sDest)
{
	bool bRes = false;
	if (CheckPath(sSource) == PATH_IS_FOLDER)
	{
		CString sTmp = sSource;
		int pos = sTmp.ReverseFind('\\');
		if (pos != -1)
		{
			sTmp.Delete(pos, sTmp.GetLength() - pos);
			if (sTmp.CompareNoCase(sDest) == 0) bRes = true;
		}
	}
	return bRes;
}