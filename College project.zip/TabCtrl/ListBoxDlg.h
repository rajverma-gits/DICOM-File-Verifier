#pragma once


// ListBoxDlg

class ListBoxDlg : public CListBox
{
	DECLARE_DYNAMIC(ListBoxDlg)

public:
	ListBoxDlg();
	virtual ~ListBoxDlg();

protected:
	DECLARE_MESSAGE_MAP()
};


