// TabThree.cpp : implementation file
//

#include "stdafx.h"
#include "TabCtrl.h"
#include "TabThree.h"
#include "afxdialogex.h"


// CTabThree dialog

IMPLEMENT_DYNAMIC(CTabThree, CDialog)

CTabThree::CTabThree(CWnd* pParent /*=NULL*/)
	: CDialog(CTabThree::IDD, pParent)
{

}

CTabThree::~CTabThree()
{
}

void CTabThree::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CTabThree, CDialog)
END_MESSAGE_MAP()


// CTabThree message handlers
