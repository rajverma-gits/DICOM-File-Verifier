// ListBoxDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TabCtrl.h"
#include "ListBoxDlg.h"


// ListBoxDlg

IMPLEMENT_DYNAMIC(ListBoxDlg, CListBox)

ListBoxDlg::ListBoxDlg()
{
}

ListBoxDlg::~ListBoxDlg()
{
}


BEGIN_MESSAGE_MAP(ListBoxDlg, CListBox)
END_MESSAGE_MAP()




// ListBoxDlg message handlers


